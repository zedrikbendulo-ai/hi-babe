BIRTHDAY LETTER WITH YOUR UPLOADED VIDEO AUDIO

1. Extract this ZIP into a normal folder.
2. Open index.html in Chrome or Microsoft Edge.
3. Click the surprise button once. Your photo appears with the uploaded video audio.
4. The audio loops while the birthday letter is open.

The photo and audio are embedded directly inside index.html. No extra media files are needed.
